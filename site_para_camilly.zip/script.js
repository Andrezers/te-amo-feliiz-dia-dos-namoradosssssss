function showMessage() {
  document.getElementById("loveCard").style.display = "block";
  document.getElementById("loveSong").play();
}
